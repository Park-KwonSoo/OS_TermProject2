#include "Scheduling.h"

Scheduling::Scheduling()
{
	this->averageWaitTime = 0;
	this->totalTime = 0;
	this->size = 0;
}
